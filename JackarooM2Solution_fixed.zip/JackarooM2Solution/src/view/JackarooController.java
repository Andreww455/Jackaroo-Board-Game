package view;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import engine.Game;
import engine.board.Cell;
import engine.board.SafeZone;
import exception.GameException;
import exception.InvalidCardException;
import exception.InvalidMarbleException;
import exception.SplitOutOfRangeException;
import model.Colour;
import model.card.Card;
import model.card.Deck;
import model.player.Marble;
import model.player.Player;

import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

/**
 * Controller for the main Jackaroo game view.
 *
 * <p>All game logic is delegated to the {@link Game} engine.  This class
 * is responsible only for:
 * <ul>
 *   <li>Rendering the board from the engine's state (single source of truth)</li>
 *   <li>Collecting player input (card selection, marble selection, split distance)</li>
 *   <li>Forwarding actions to the engine and handling exceptions</li>
 * </ul>
 */
public class JackarooController {

    // ── FXML injected fields ───────────────────────────────────────────────────
    @FXML private GridPane  boardGrid;
    @FXML private HBox      playerInfoPanel;
    @FXML private VBox      gameControlPanel;
    @FXML private TextArea  gameMessageArea;
    @FXML private Label     currentActionLabel;
    @FXML private Button    playCardButton;
    @FXML private Button    skipTurnButton;
    @FXML private ComboBox<String> marbleSelector; // kept for FXML compat – hidden at runtime
    @FXML private TextField splitDistanceField;
    @FXML private HBox      cardHandContainer;
    @FXML private Label     deckSizeLabel;
    @FXML private Label     firePitSizeLabel;

    // ── Engine ────────────────────────────────────────────────────────────────
    private Game gameEngine;

    // ── Action-state machine ──────────────────────────────────────────────────
    private Card   selectedCard;
    /**
     * Current action mode. Possible values:
     * NONE, FIELD, MOVE, MOVE_BACK, MOVE_ANY,
     * DISCARD_RANDOM, DISCARD_NEXT,
     * JACK_SWAP, SEVEN_SPLIT, BURN, SAVE
     */
    private String currentAction   = "NONE";
    private int    marblesNeeded   = 0;
    private int    marblesSelected = 0;

    // ── Board UI structures ───────────────────────────────────────────────────
    private List<StackPane>                  trackCellViews;
    private HashMap<Colour, List<StackPane>> safeZoneCellViews;
    private HashMap<Colour, VBox>            homeZoneViews;
    private HashMap<Colour, HBox>            playerInfoViews;
    private List<VBox>                       cardViews;
    private HBox                             actionChoiceBox;
    private final List<StackPane>            highlightedCells = new ArrayList<>();

    // ── Layout constants ──────────────────────────────────────────────────────
    private static final int BOARD_SIZE  = 26;
    private static final int CENTER_X    = 15;
    private static final int CENTER_Y    = 15;
    private static final int TRACK_CELLS = 100;

    // ═══════════════════════════════════════════════════════════════════════
    // Initialisation
    // ═══════════════════════════════════════════════════════════════════════

    @FXML
    private void initialize() {
        splitDistanceField.setText("1");
        playCardButton.setDisable(true);
        skipTurnButton.setDisable(true);
        marbleSelector.setDisable(true);
        marbleSelector.setVisible(false); // not used – hidden for cleaner UI
        splitDistanceField.setDisable(true);
    }

    /** Called by {@link Main} after the scene is shown. */
    public void initializeGame(String playerName) {
        try {
            this.gameEngine = new Game(playerName);
            cardViews = new ArrayList<>();
            initializeBoard();
            initializePlayerInfo();

            gameMessageArea.setText("Welcome to Jackaroo, " + playerName + "!\n");
            gameMessageArea.appendText("Your colour: "
                    + gameEngine.getPlayers().get(0).getColour() + "\n");
            gameMessageArea.appendText("Move all 4 marbles to your Safe Zone to win.\n\n");
        } catch (java.io.IOException e) {
            e.printStackTrace();
        }
    }

    // ── Board layout ──────────────────────────────────────────────────────────

    private void initializeBoard() {
        boardGrid.getChildren().clear();

        // Empty background cells
        for (int r = 0; r < BOARD_SIZE; r++)
            for (int c = 0; c < BOARD_SIZE; c++) {
                StackPane bg = new StackPane();
                bg.setPrefSize(40, 40);
                boardGrid.add(bg, c, r);
            }

        // Tan inner surface
        StackPane inner = new StackPane();
        inner.getStyleClass().add("board-inner");
        inner.setPrefSize(600, 1200);
        boardGrid.add(inner, 1, 1, BOARD_SIZE - 2, BOARD_SIZE - 2);

        // Fire-pit label in the centre
        VBox firePit = new VBox();
        firePit.getStyleClass().add("fire-pit");
        firePit.setPrefSize(100, 150);
        firePit.setAlignment(Pos.CENTER);
        Label fpLabel = new Label("FirePit");
        fpLabel.getStyleClass().add("fire-pit-label");
        firePit.getChildren().add(fpLabel);
        boardGrid.add(firePit, CENTER_X - 1, CENTER_Y - 1, 2, 2);

        // 100-cell track
        trackCellViews = new ArrayList<>();
        for (int i = 0; i < TRACK_CELLS; i++)
            trackCellViews.add(createTrackCellView(i));
        layoutTrackCells();

        initializeSafeZonesAndHomeZones();
        addPositionLabels();
    }

    private StackPane createTrackCellView(int index) {
        StackPane cell = new StackPane();
        cell.setPrefSize(5, 5);
        cell.setMinSize(5, 5);
        cell.setMaxSize(5, 5);

        Cell engineCell = gameEngine.getBoard().getTrack().get(index);
        switch (engineCell.getCellType()) {
            case BASE:  cell.getStyleClass().addAll("cell", "base-cell");  break;
            case ENTRY: cell.getStyleClass().addAll("cell", "entry-cell"); break;
            default:
                cell.getStyleClass().add("cell");
                if (engineCell.isTrap()) cell.getStyleClass().add("trap-cell");
                break;
        }

        Circle marble = new Circle(4);
        marble.getStyleClass().add("marble");
        marble.setVisible(false);
        cell.getChildren().add(marble);
        cell.setUserData(index);
        cell.setOnMouseClicked(e -> handleCellClick(cell));
        return cell;
    }

    private void layoutTrackCells() {
        boardGrid.getStyleClass().add("board-grid");
        final int C  = 12; // grid centre index
        final int SL = 20; // side length
        final int AL = 5;  // arm length

        int idx = 0;
        for (int i = 0; i < SL; i++) boardGrid.add(trackCellViews.get(idx++), C - 11 + i, C + 13); // bottom →
        for (int i = 0; i < SL; i++) boardGrid.add(trackCellViews.get(idx++), C + 13, C + 7 - i);  // right ↑
        for (int i = 0; i < SL; i++) boardGrid.add(trackCellViews.get(idx++), C + 8 - i, C - 12);  // top ←
        for (int i = 0; i < SL; i++) boardGrid.add(trackCellViews.get(idx++), C - 11, C - 12 + i); // left ↓
        for (int i = 0; i < AL; i++) boardGrid.add(trackCellViews.get(idx++), C + 13, C + 13 - i); // bottom arm
        for (int i = 0; i < AL; i++) boardGrid.add(trackCellViews.get(idx++), C + 12 - i, C + 13); // right arm
        for (int i = 0; i < AL; i++) boardGrid.add(trackCellViews.get(idx++), C - 11, C + 9 + i);  // top arm
        for (int i = 0; i < AL; i++) boardGrid.add(trackCellViews.get(idx++), C + 9 + i, C - 12);  // left arm
    }

    private void initializeSafeZonesAndHomeZones() {
        safeZoneCellViews = new HashMap<>();
        homeZoneViews     = new HashMap<>();

        for (Colour colour : Colour.values()) {
            List<StackPane> szCells = new ArrayList<>();
            for (int i = 0; i < 4; i++) szCells.add(createSafeZoneCell());
            safeZoneCellViews.put(colour, szCells);
            homeZoneViews.put(colour, createHomeZoneView(colour));
        }

        // RED – base 0, entry 98
        HBox redSZ = new HBox(2);
        redSZ.getStyleClass().add("safe-zone");
        redSZ.getChildren().addAll(safeZoneCellViews.get(Colour.RED));
        boardGrid.add(redSZ, CENTER_X + 1, CENTER_Y + 9, 4, 1);
        boardGrid.add(homeZoneViews.get(Colour.RED), CENTER_X - 2, CENTER_Y + 8, 2, 2);

        // YELLOW – base 75, entry 73
        VBox yellowSZ = new VBox(2);
        yellowSZ.getStyleClass().add("safe-zone");
        yellowSZ.getChildren().addAll(safeZoneCellViews.get(Colour.YELLOW));
        boardGrid.add(yellowSZ, CENTER_X - 13, CENTER_Y - 2, 1, 4);
        boardGrid.add(homeZoneViews.get(Colour.YELLOW), CENTER_X - 13, CENTER_Y - 4, 2, 2);

        // BLUE – base 50, entry 48
        HBox blueSZ = new HBox(2);
        blueSZ.getStyleClass().add("safe-zone");
        blueSZ.getChildren().addAll(safeZoneCellViews.get(Colour.BLUE));
        boardGrid.add(blueSZ, CENTER_X - 8, CENTER_Y - 14, 4, 1);
        boardGrid.add(homeZoneViews.get(Colour.BLUE), CENTER_X - 4, CENTER_Y - 14, 2, 2);

        // GREEN – base 25, entry 23
        VBox greenSZ = new VBox(2);
        greenSZ.getStyleClass().add("safe-zone");
        greenSZ.getChildren().addAll(safeZoneCellViews.get(Colour.GREEN));
        boardGrid.add(greenSZ, CENTER_X + 9, CENTER_Y - 5, 1, 4);
        boardGrid.add(homeZoneViews.get(Colour.GREEN), CENTER_X + 7, CENTER_Y - 7, 2, 2);
    }

    private StackPane createSafeZoneCell() {
        StackPane cell = new StackPane();
        cell.setPrefSize(20, 20);
        cell.setMinSize(20, 20);
        cell.setMaxSize(20, 20);
        cell.getStyleClass().add("safe-cell");
        Circle m = new Circle(8);
        m.getStyleClass().add("marble");
        m.setVisible(false);
        cell.getChildren().add(m);
        return cell;
    }

    private VBox createHomeZoneView(Colour colour) {
        VBox zone = new VBox(5);
        zone.setAlignment(Pos.CENTER);
        zone.getStyleClass().add("home-zone");

        Label lbl = new Label("Home");
        lbl.setTextFill(Color.WHITE);
        lbl.getStyleClass().add("home-zone-label");

        HBox marbleRow = new HBox(5);
        marbleRow.setAlignment(Pos.CENTER);
        for (int i = 0; i < 4; i++) {
            Circle c = new Circle(8);
            c.setFill(toFxColor(colour));
            c.getStyleClass().addAll("marble", "marble-" + colour.name().toLowerCase());
            marbleRow.getChildren().add(c);
        }
        zone.getChildren().addAll(lbl, marbleRow);
        zone.setOnMouseClicked(e -> handleHomeZoneClick(colour));
        return zone;
    }

    private void addPositionLabels() {
        placeLabel("0",  CENTER_X,      CENTER_Y + 10);
        placeLabel("25", CENTER_X - 15, CENTER_Y - 3);
        placeLabel("50", CENTER_X,      CENTER_Y - 15);
        placeLabel("75", CENTER_X + 10, CENTER_Y - 3);
    }

    private void placeLabel(String text, int col, int row) {
        Label l = new Label(text);
        l.setFont(Font.font("System", FontWeight.BOLD, 12));
        l.setTextFill(Color.WHITE);
        boardGrid.add(l, col, row);
    }

    // ── Player info panel ─────────────────────────────────────────────────────

    private void initializePlayerInfo() {
        playerInfoViews = new HashMap<>();
        playerInfoPanel.getChildren().clear();
        for (Player p : gameEngine.getPlayers()) {
            HBox info = createPlayerInfoView(p);
            playerInfoViews.put(p.getColour(), info);
            playerInfoPanel.getChildren().add(info);
        }
    }

    private HBox createPlayerInfoView(Player player) {
        HBox row = new HBox(10);
        row.setAlignment(Pos.CENTER);
        row.setPadding(new Insets(5));
        row.getStyleClass().add("player-info");

        Circle indicator = new Circle(10);
        indicator.setFill(toFxColor(player.getColour()));
        indicator.getStyleClass().addAll("marble",
                "marble-" + player.getColour().name().toLowerCase());

        VBox data = new VBox(3);
        data.setAlignment(Pos.CENTER_LEFT);

        Label nameLabel   = new Label(player.getName());
        nameLabel.setTextFill(toFxColor(player.getColour()));
        nameLabel.setFont(Font.font("System", FontWeight.BOLD, 14));

        Label cardsLabel  = new Label("Cards: " + player.getHand().size());
        Label statusLabel = new Label("Waiting");

        data.getChildren().addAll(nameLabel, cardsLabel, statusLabel);
        row.getChildren().addAll(indicator, data);
        row.setUserData(new Label[]{nameLabel, cardsLabel, statusLabel});
        return row;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Game flow
    // ═══════════════════════════════════════════════════════════════════════

    /** Called by {@link Main} after {@link #initializeGame}. */
    public void startGame() {
        setupButtonHandlers();
        updateView();
        startPlayerTurn();
    }

    private void setupButtonHandlers() {
        playCardButton.setOnAction(e -> playCard());
        skipTurnButton.setOnAction(e -> skipTurn());
        splitDistanceField.setOnAction(e -> applySplitDistance());
    }

    private void startPlayerTurn() {
        Colour active = gameEngine.getActivePlayerColour();
        Player current = getPlayerByColour(active);
        if (current == null) return;

        currentActionLabel.setText(current.getName() + "'s turn");
        displayMessage("─── " + current.getName() + "'s turn ───");
        updatePlayerInfo();

        boolean isHuman = (active == gameEngine.getPlayers().get(0).getColour());
        if (isHuman) {
            updateCardHand(current.getHand());
            skipTurnButton.setDisable(false);
        } else {
            updateCardHand(new ArrayList<>());
            PauseTransition pause = new PauseTransition(Duration.seconds(1.2));
            pause.setOnFinished(ev -> playCPUTurn());
            pause.play();
        }
    }

    private void playCPUTurn() {
        Player cpu = getPlayerByColour(gameEngine.getActivePlayerColour());
        try {
            gameEngine.playPlayerTurn();
            displayMessage(cpu.getName() + " played a card.");
        } catch (GameException ex) {
            displayMessage(cpu.getName() + " had no valid move – discarding.");
            if (!cpu.getHand().isEmpty()) {
                try { gameEngine.selectCard(cpu.getHand().get(0)); }
                catch (InvalidCardException ignored) {}
            }
        }
        endTurn();
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Card selection
    // ═══════════════════════════════════════════════════════════════════════

    private void handleCardSelection(VBox cardView) {
        int index = cardViews.indexOf(cardView);
        if (index < 0) return;

        Card card = gameEngine.getPlayers().get(0).getHand().get(index);

        // Clear any previous engine selections, then select this card
        gameEngine.deselectAll();
        try {
            gameEngine.selectCard(card);
        } catch (InvalidCardException ex) {
            displayError("Card Selection", ex.getMessage());
            return;
        }
        selectedCard = card;

        // Visual highlight
        for (VBox cv : cardViews) cv.getStyleClass().remove("card-selected");
        cardView.getStyleClass().add("card-selected");

        // Reset UI state (does not touch engine)
        resetSelectionUI();

        // Show context buttons for multi-mode cards
        showActionChoices(card);
    }

    /** Resets only UI state – engine's selected card is already set. */
    private void resetSelectionUI() {
        currentAction   = "NONE";
        marblesNeeded   = 0;
        marblesSelected = 0;
        playCardButton.setDisable(true);
        splitDistanceField.setDisable(true);
        clearHighlights();
        removeActionChoiceBox();
    }

    private void showActionChoices(Card card) {
        switch (card.getName()) {
            case "Ace":
                makeChoiceBox("Field Marble", "FIELD", "Move Forward (1)", "MOVE");
                currentActionLabel.setText("Choose Ace action:");
                break;
            case "King":
                makeChoiceBox("Field Marble", "FIELD", "Move Forward (13, destroys path)", "MOVE");
                currentActionLabel.setText("Choose King action:");
                break;
            case "Queen":
                makeChoiceBox("Discard Random Player's Card", "DISCARD_RANDOM",
                              "Move Forward (12)", "MOVE");
                currentActionLabel.setText("Choose Queen action:");
                break;
            case "Ten":
                makeChoiceBox("Discard Next Player's Card", "DISCARD_NEXT",
                              "Move Forward (10)", "MOVE");
                currentActionLabel.setText("Choose Ten action:");
                break;
            case "Jack":
                makeChoiceBox("Swap Marbles (own + opponent)", "JACK_SWAP",
                              "Move Forward (11)", "MOVE");
                currentActionLabel.setText("Choose Jack action:");
                break;
            case "Seven":
                makeChoiceBox("Split Move (7 total)", "SEVEN_SPLIT",
                              "Move Forward (7)", "MOVE");
                currentActionLabel.setText("Choose Seven action:");
                break;
            case "Four":
                setActionMode("MOVE_BACK");
                break;
            case "Five":
                setActionMode("MOVE_ANY");
                break;
            case "MarbleBurner":
                setActionMode("BURN");
                break;
            case "MarbleSaver":
                setActionMode("SAVE");
                break;
            default:
                // Two, Three, Six, Eight, Nine – plain forward move
                setActionMode("MOVE");
                break;
        }
    }

    private void makeChoiceBox(String labelA, String actionA,
                                String labelB, String actionB) {
        removeActionChoiceBox();
        actionChoiceBox = new HBox(8);
        actionChoiceBox.setAlignment(Pos.CENTER);
        actionChoiceBox.setPadding(new Insets(4));
        actionChoiceBox.getChildren().addAll(
                makeActionBtn(labelA, actionA),
                makeActionBtn(labelB, actionB));
        // Insert just below currentActionLabel (index 0) in the control panel
        int at = Math.min(1, gameControlPanel.getChildren().size());
        gameControlPanel.getChildren().add(at, actionChoiceBox);
    }

    private Button makeActionBtn(String label, String action) {
        Button btn = new Button(label);
        btn.getStyleClass().add("action-choice-btn");
        btn.setOnAction(e -> setActionMode(action));
        return btn;
    }

    private void removeActionChoiceBox() {
        if (actionChoiceBox != null) {
            gameControlPanel.getChildren().remove(actionChoiceBox);
            actionChoiceBox = null;
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Action-mode state machine
    // ═══════════════════════════════════════════════════════════════════════

    private void setActionMode(String action) {
        currentAction   = action;
        marblesSelected = 0;
        clearHighlights();

        // Clear marble selections, keep card selected
        gameEngine.deselectAll();
        if (selectedCard != null) {
            try { gameEngine.selectCard(selectedCard); }
            catch (InvalidCardException ignored) {}
        }

        switch (action) {
            case "FIELD":
            case "DISCARD_RANDOM":
            case "DISCARD_NEXT":
                marblesNeeded = 0;
                playCardButton.setDisable(false);
                splitDistanceField.setDisable(true);
                break;

            case "JACK_SWAP":
                marblesNeeded = 2;
                playCardButton.setDisable(true);
                splitDistanceField.setDisable(true);
                break;

            case "SEVEN_SPLIT":
                marblesNeeded = 2;
                playCardButton.setDisable(true);
                splitDistanceField.setDisable(false);
                break;

            default: // MOVE, MOVE_BACK, MOVE_ANY, BURN, SAVE
                marblesNeeded = 1;
                playCardButton.setDisable(true);
                splitDistanceField.setDisable(true);
                break;
        }

        currentActionLabel.setText(modeHint(action));
    }

    private String modeHint(String action) {
        switch (action) {
            case "FIELD":          return "Click 'Play Card' to field a marble.";
            case "DISCARD_RANDOM": return "Click 'Play Card' to discard a random player's card.";
            case "DISCARD_NEXT":   return "Click 'Play Card' to discard the next player's card.";
            case "MOVE":           return "Click one of YOUR marbles on the board.";
            case "MOVE_BACK":      return "Click one of YOUR marbles to move it 4 steps back.";
            case "MOVE_ANY":       return "Click ANY marble on the board (moves 5 steps forward).";
            case "BURN":           return "Click an OPPONENT's marble on the board.";
            case "SAVE":           return "Click one of YOUR marbles on the board to save it.";
            case "JACK_SWAP":      return "Click YOUR marble first.";
            case "SEVEN_SPLIT":    return "Set split distance, then click 2 of your marbles.";
            default:               return "Click a marble.";
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Marble selection
    // ═══════════════════════════════════════════════════════════════════════

    private void handleCellClick(StackPane cellView) {
        if (selectedCard == null || marblesNeeded == 0) return;
        if (marblesSelected >= marblesNeeded) return;

        int idx = (int) cellView.getUserData();
        Marble marble = gameEngine.getBoard().getTrack().get(idx).getMarble();

        if (marble == null) {
            displayMessage("No marble at cell " + idx + ".");
            return;
        }
        if (!isValidMarble(marble)) {
            displayMessage("That marble cannot be selected for this action.");
            return;
        }

        try {
            gameEngine.selectMarble(marble);
            marblesSelected++;
            cellView.getStyleClass().add("cell-selected");
            highlightedCells.add(cellView);
            updateAfterMarbleSelect();
        } catch (InvalidMarbleException ex) {
            displayError("Marble Selection", ex.getMessage());
        }
    }

    private void handleHomeZoneClick(Colour colour) {
        if (!"FIELD".equals(currentAction)) return;
        if (colour != gameEngine.getPlayers().get(0).getColour()) return;
        displayMessage("Click 'Play Card' to field a marble from your Home Zone.");
    }

    private boolean isValidMarble(Marble marble) {
        Colour active = gameEngine.getActivePlayerColour();
        switch (currentAction) {
            case "MOVE":
            case "MOVE_BACK":
            case "SAVE":
                return marble.getColour() == active;
            case "MOVE_ANY":
                return true;
            case "BURN":
                return marble.getColour() != active;
            case "JACK_SWAP":
                return (marblesSelected == 0)
                        ? marble.getColour() == active
                        : marble.getColour() != active;
            case "SEVEN_SPLIT":
                return marble.getColour() == active;
            default:
                return marble.getColour() == active;
        }
    }

    private void updateAfterMarbleSelect() {
        if (marblesSelected >= marblesNeeded) {
            playCardButton.setDisable(false);
            currentActionLabel.setText("Ready! Click 'Play Card'.");
        } else {
            if ("JACK_SWAP".equals(currentAction))
                currentActionLabel.setText("Now click an OPPONENT's marble.");
            else if ("SEVEN_SPLIT".equals(currentAction))
                currentActionLabel.setText("Now click your second marble.");
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Play / skip / end turn
    // ═══════════════════════════════════════════════════════════════════════

    private void playCard() {
        if (selectedCard == null) return;

        // Commit split distance if applicable
        if ("SEVEN_SPLIT".equals(currentAction) && !applySplitDistance()) return;

        try {
            gameEngine.playPlayerTurn();
            displayMessage("You played " + selectedCard.getName() + " – " + actionSummary());
            endTurn();
        } catch (GameException ex) {
            displayError("Invalid Move", ex.getMessage());
            // Allow retry: clear marble selections but keep card
            marblesSelected = 0;
            clearHighlights();
            gameEngine.deselectAll();
            if (selectedCard != null) {
                try { gameEngine.selectCard(selectedCard); }
                catch (InvalidCardException ignored) {}
            }
            playCardButton.setDisable(marblesNeeded > 0);
            currentActionLabel.setText(modeHint(currentAction));
        }
    }

    /** Discards the player's first card without playing it (uses up the turn). */
    private void skipTurn() {
        Player human = gameEngine.getPlayers().get(0);
        if (human.getHand().isEmpty()) return;
        try {
            Card discard = human.getHand().get(0);
            gameEngine.deselectAll();
            gameEngine.selectCard(discard);
            selectedCard = discard;
            displayMessage("Skipped turn – discarded: " + discard.getName());
            endTurn();
        } catch (InvalidCardException ex) {
            displayError("Skip Turn", ex.getMessage());
        }
    }

    /**
     * Reads the split-distance text field and calls the engine.
     * Returns {@code true} on success.
     */
    private boolean applySplitDistance() {
        try {
            int dist = Integer.parseInt(splitDistanceField.getText().trim());
            gameEngine.editSplitDistance(dist);
            return true;
        } catch (NumberFormatException ex) {
            displayError("Split Distance", "Please enter a whole number between 1 and 6.");
            splitDistanceField.setText("1");
            return false;
        } catch (SplitOutOfRangeException ex) {
            displayError("Split Distance", ex.getMessage());
            splitDistanceField.setText("1");
            return false;
        }
    }

    private void endTurn() {
        gameEngine.endPlayerTurn();

        // Reset all selection state
        selectedCard    = null;
        currentAction   = "NONE";
        marblesNeeded   = 0;
        marblesSelected = 0;
        clearHighlights();
        removeActionChoiceBox();
        for (VBox cv : cardViews) cv.getStyleClass().remove("card-selected");
        playCardButton.setDisable(true);
        skipTurnButton.setDisable(true);
        splitDistanceField.setDisable(true);

        // Check win condition
        Colour winner = gameEngine.checkWin();
        updateView();
        if (winner != null) {
            gameOver(winner);
        } else {
            startPlayerTurn();
        }
    }

    private String actionSummary() {
        switch (currentAction) {
            case "FIELD":          return "fielded a marble.";
            case "DISCARD_RANDOM": return "discarded a random player's card.";
            case "DISCARD_NEXT":   return "discarded the next player's card.";
            case "BURN":           return "burned an opponent's marble.";
            case "SAVE":           return "saved a marble to the Safe Zone.";
            case "JACK_SWAP":      return "swapped marbles.";
            case "SEVEN_SPLIT":    return "split-moved 7 steps.";
            case "MOVE_BACK":      return "moved backward 4 steps.";
            case "MOVE_ANY":       return "moved a marble 5 steps.";
            default:               return "moved forward.";
        }
    }

    // ═══════════════════════════════════════════════════════════════════════
    // View update – reads from engine (single source of truth)
    // ═══════════════════════════════════════════════════════════════════════

    private void updateView() {
        updatePlayerInfo();
        updateHomeZones();
        updateBoardFromEngine();
        updateDeckAndFirePit();
    }

    private void updatePlayerInfo() {
        Colour active = gameEngine.getActivePlayerColour();
        for (Player p : gameEngine.getPlayers()) {
            HBox info = playerInfoViews.get(p.getColour());
            if (info == null) continue;
            Label[] labels = (Label[]) info.getUserData();
            labels[1].setText("Cards: " + p.getHand().size());
            boolean isCurrent = p.getColour() == active;
            labels[2].setText(isCurrent ? "▶ Active" : "Waiting");
            labels[2].setTextFill(isCurrent ? Color.GREEN : Color.GRAY);
            if (isCurrent) info.getStyleClass().add("player-info-active");
            else           info.getStyleClass().remove("player-info-active");
        }
    }

    private void updateHomeZones() {
        for (Player p : gameEngine.getPlayers()) {
            VBox zone = homeZoneViews.get(p.getColour());
            if (zone == null || zone.getChildren().size() < 2) continue;
            HBox marbleRow = (HBox) zone.getChildren().get(1);
            int atHome = p.getMarbles().size(); // marbles still in Home Zone
            for (int i = 0; i < marbleRow.getChildren().size(); i++)
                marbleRow.getChildren().get(i).setVisible(i < atHome);
        }
    }

    /**
     * Clears all marble visuals and redraws from the engine's track and
     * safe zones.  This is the ONLY place marble positions are rendered.
     */
    private void updateBoardFromEngine() {
        // Clear track
        for (StackPane cell : trackCellViews) {
            Circle c = findMarbleCircle(cell);
            if (c != null) c.setVisible(false);
        }
        // Clear safe zones
        for (List<StackPane> szCells : safeZoneCellViews.values())
            for (StackPane cell : szCells) {
                Circle c = findMarbleCircle(cell);
                if (c != null) c.setVisible(false);
            }

        // Draw track marbles
        List<Cell> track = gameEngine.getBoard().getTrack();
        for (int i = 0; i < track.size(); i++) {
            Marble m = track.get(i).getMarble();
            if (m == null) continue;
            Circle c = findOrCreateCircle(trackCellViews.get(i), 4);
            applyMarbleColour(c, m.getColour());
            c.setVisible(true);
        }

        // Draw safe-zone marbles
        for (SafeZone sz : gameEngine.getBoard().getSafeZones()) {
            List<StackPane> szViews = safeZoneCellViews.get(sz.getColour());
            if (szViews == null) continue;
            List<Cell> szCells = sz.getCells();
            for (int i = 0; i < szCells.size() && i < szViews.size(); i++) {
                Marble m = szCells.get(i).getMarble();
                if (m == null) continue;
                Circle c = findOrCreateCircle(szViews.get(i), 8);
                applyMarbleColour(c, m.getColour());
                c.setVisible(true);
            }
        }
    }

    private Circle findMarbleCircle(StackPane pane) {
        for (javafx.scene.Node n : pane.getChildren())
            if (n instanceof Circle && ((Circle) n).getStyleClass().contains("marble"))
                return (Circle) n;
        return null;
    }

    private Circle findOrCreateCircle(StackPane pane, double radius) {
        Circle c = findMarbleCircle(pane);
        if (c == null) {
            c = new Circle(radius);
            c.getStyleClass().add("marble");
            pane.getChildren().add(c);
        }
        return c;
    }

    private void applyMarbleColour(Circle c, Colour colour) {
        c.getStyleClass().removeIf(s -> s.startsWith("marble-"));
        c.getStyleClass().add("marble-" + colour.name().toLowerCase());
        c.setFill(toFxColor(colour));
    }

    private void updateDeckAndFirePit() {
        deckSizeLabel.setText(String.valueOf(Deck.getPoolSize()));
        firePitSizeLabel.setText(String.valueOf(gameEngine.getFirePit().size()));
    }

    private void updateCardHand(List<Card> cards) {
        cardHandContainer.getChildren().clear();
        cardViews.clear();
        for (Card card : cards) {
            VBox view = createCardView(card);
            cardViews.add(view);
            cardHandContainer.getChildren().add(view);
        }
    }

    // ── Card tile rendering ───────────────────────────────────────────────────

    private VBox createCardView(Card card) {
        VBox tile = new VBox(4);
        tile.setAlignment(Pos.CENTER);
        tile.setPadding(new Insets(4));
        tile.getStyleClass().add("card");
        tile.setPrefSize(100, 145);

        Rectangle bg = new Rectangle(90, 125);
        bg.setFill(Color.WHITE);
        bg.setStroke(Color.DARKGRAY);
        bg.setStrokeWidth(1.5);
        bg.setArcWidth(10);
        bg.setArcHeight(10);

        Label nameLbl = new Label(card.getName());
        nameLbl.setFont(Font.font("System", FontWeight.BOLD, 11));
        nameLbl.setWrapText(true);
        nameLbl.setMaxWidth(82);
        nameLbl.setAlignment(Pos.CENTER);
        nameLbl.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        Label descLbl = new Label(card.getDescription());
        descLbl.setWrapText(true);
        descLbl.setMaxWidth(82);
        descLbl.setFont(Font.font("System", 8));
        descLbl.setAlignment(Pos.CENTER);
        descLbl.setTextAlignment(javafx.scene.text.TextAlignment.CENTER);

        VBox content = new VBox(4);
        content.setAlignment(Pos.CENTER);
        content.setPadding(new Insets(4));
        content.getChildren().addAll(nameLbl, descLbl);

        StackPane face = new StackPane();
        face.getChildren().addAll(bg, content);
        tile.getChildren().add(face);
        tile.setOnMouseClicked(e -> handleCardSelection(tile));
        return tile;
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Game over
    // ═══════════════════════════════════════════════════════════════════════

    private void gameOver(Colour winnerColour) {
        Player winner = getPlayerByColour(winnerColour);
        String name   = (winner != null) ? winner.getName() : winnerColour.name();
        displayMessage("🏆  GAME OVER — " + name + " wins!");
        currentActionLabel.setText("🏆  " + name + " wins!");
        showGameOverOverlay(name);
    }

    private void showGameOverOverlay(String winnerName) {
        StackPane overlay = new StackPane();
        overlay.getStyleClass().add("game-over-pane");

        VBox box = new VBox(20);
        box.setAlignment(Pos.CENTER);
        box.setPadding(new Insets(30));
        box.setStyle("-fx-background-color: rgba(0,0,0,0.78); -fx-background-radius: 18;");

        Label title = new Label("GAME OVER");
        title.setFont(Font.font("System", FontWeight.BOLD, 40));
        title.setTextFill(Color.GOLD);

        Label msg = new Label(winnerName + " wins! 🎉");
        msg.setFont(Font.font("System", FontWeight.BOLD, 26));
        msg.setTextFill(Color.WHITE);

        Button close = new Button("Close");
        close.setOnAction(e -> boardGrid.getChildren().remove(overlay));

        box.getChildren().addAll(title, msg, close);
        overlay.getChildren().add(box);
        boardGrid.add(overlay, 0, 0, BOARD_SIZE, BOARD_SIZE);
    }

    // ═══════════════════════════════════════════════════════════════════════
    // Utilities
    // ═══════════════════════════════════════════════════════════════════════

    private void clearHighlights() {
        for (StackPane cell : highlightedCells)
            cell.getStyleClass().remove("cell-selected");
        highlightedCells.clear();
    }

    private Player getPlayerByColour(Colour colour) {
        for (Player p : gameEngine.getPlayers())
            if (p.getColour() == colour) return p;
        return null;
    }

    private Color toFxColor(Colour colour) {
        switch (colour) {
            case RED:    return Color.CRIMSON;
            case GREEN:  return Color.LIMEGREEN;
            case BLUE:   return Color.ROYALBLUE;
            case YELLOW: return Color.GOLD;
            default:     return Color.GRAY;
        }
    }

    private void displayMessage(String msg) {
        gameMessageArea.appendText(msg + "\n");
        gameMessageArea.setScrollTop(Double.MAX_VALUE);
    }

    private void displayError(String title, String msg) {
        gameMessageArea.appendText("[!] " + title + ": " + msg + "\n");
        gameMessageArea.setScrollTop(Double.MAX_VALUE);
        String orig = gameMessageArea.getStyle();
        gameMessageArea.setStyle("-fx-border-color: #e53935; -fx-border-width: 2;");
        PauseTransition pt = new PauseTransition(Duration.seconds(2));
        pt.setOnFinished(e -> gameMessageArea.setStyle(orig));
        pt.play();
    }
}
